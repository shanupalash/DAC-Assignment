import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet  extends HttpServlet
{
	
	public void doPost(HttpServletRequest  request, HttpServletResponse response) throws IOException                                      
	{
		
		
		response.setContentType("text/html");
		
		
		String uname =request.getParameter("username");
		String pwd =request.getParameter("password");
		PrintWriter out = response.getWriter();
		
		if (uname.equals("admin") && pwd.equals("admin123"))
		{
					
			   response.sendRedirect("success.html");
		
		}else
		{
			response.sendRedirect("error.html");
		}
		
		
		
		
		
		
		
		
		
	}
	
	

}
