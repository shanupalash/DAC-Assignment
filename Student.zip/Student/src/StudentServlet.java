
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class StudentServlet  extends HttpServlet
{
	
	public void doPost(HttpServletRequest  request, HttpServletResponse response) throws IOException                                      
	{
		
		
		response.setContentType("text/html");
		
		
		int sid =Integer.parseInt(request.getParameter("sid"));
		String name =request.getParameter("name");
		String email =request.getParameter("email");
		String address =request.getParameter("address");
		
		PrintWriter out = response.getWriter();
		
		out.println("<h1> registered successfully </h1>");
		
        // Display the data
        out.println("<html><body>");
        out.println("<h2>Student Registered Successfully!</h2>");
        out.println("<p><strong>Student ID:</strong> " + sid + "</p>");
        out.println("<p><strong>Name:</strong> " + name + "</p>");
        out.println("<p><strong>Email:</strong> " + email + "</p>");
        out.println("<p><strong>Address:</strong> " + address + "</p>");
        out.println("</body></html>");

		
		
		
		
		
		
		
		
	}
	
	

}
