package com.example;

import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;



@Controller
public class WelcomeController 
{
//	ArrayList<Student> al= new ArrayList<>();
	
	
	
    @RequestMapping("/hello")
    public String welcomeMessage(Model model)
	{
		
		String msg = "welcome to Spring MVC";
		
		model.addAttribute("message",msg);
		
		return "welcome";
		
	}
    
    @RequestMapping("/user")
    public String userwelcome()
	{
		
		return "user";
		
	}
    
    
    
    @RequestMapping("/user-form")
    public String userform(@RequestParam("username") String user ,
    		    @RequestParam("pwd") String pwd,Model model)
	{
		
		if(user.equals("admin")&& pwd.equals("1234"))
		{
			String msg = user +"welcome to Spring MVC";
			
			model.addAttribute("message",msg);
			return "welcome";
		}else
		{
    	   return "error";
		} 
    	
		
		
		
	}                                               
    @GetMapping("/register")
    
    public String userform(Model model)
	{
		
      	Student stu = new Student();
      	model.addAttribute("student", stu);
	   return "register";
		
	}
    
    
    @PostMapping("/add-student")
    public String userentry(@ModelAttribute("student") Student student,Model model) throws ClassNotFoundException, SQLException
	{
		//al.add(student);
		
		StudentDAO sd = new StudentDAO();
		sd.saveStudent(student);
		
		ArrayList<Student> al=sd.getStudent();
		
        model.addAttribute("students", al);
        
        return "student-list";
		
	}
    
    @GetMapping("/students")
    public String userentry(Model model) throws ClassNotFoundException, SQLException
	{		
		StudentDAO sd = new StudentDAO();
		ArrayList<Student> al=sd.getStudent();
		
        model.addAttribute("students", al);
        
        return "student-list";	
	}
    

    
    @GetMapping("/delete-student")
    public String deleteStudent(@RequestParam("sid") int sid) throws ClassNotFoundException, SQLException {
        // Log the student SID for debugging (consider using logging instead of System.out.println)
        System.out.println("Student to be deleted: SID = " + sid);

        // Create the DAO object
        StudentDAO sd = new StudentDAO();

        // Create a Student object based on the sid to be deleted
        Student student = new Student();
        student.setSid(sid);

        // Call the delete method
        sd.deleteStudent(student);

        // Fetch the updated list of students after deletion
//        ArrayList<Student> al = sd.getStudent();
//
//        // Add the updated list of students to the model
//        model.addAttribute("students", al);

        // Redirect to the student list page after deletion
        return "redirect:/students"; 
    }
   
    @GetMapping("/update-student")
    public String showUpdateForm(@RequestParam("sid") int sid, Model model) throws Exception {
        StudentDAO sd = new StudentDAO();
        ArrayList<Student> students = sd.getStudent();
        
        // Find student by sid
        for (Student s : students) {
            if (s.getSid() == sid) {
                model.addAttribute("student", s);
                break;
            }
        }
        return "update-student-form";  
    }

    
    @PostMapping("/update-student")
    public String updateStudent(@ModelAttribute Student student) throws Exception {
        StudentDAO sd = new StudentDAO();
        sd.UpdateStudent(student);
        return "redirect:/students";

    }

    
    
}
