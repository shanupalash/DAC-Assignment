package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class StudentDAO 
{

	ArrayList<Student> al= new ArrayList<>();
	
	public void saveStudent(Student student) throws SQLException, ClassNotFoundException
	{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "1234"); 
        String sql = "INSERT INTO student (sid,name, email, course) VALUES (?,?, ?, ?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, student.getSid());
        ps.setString(2, student.getName());
        ps.setString(3, student.getEmail());
        ps.setString(4, student.getCourse());
        ps.executeUpdate();

		
		
	}
	
	
	
	public ArrayList<Student> getStudent() throws SQLException, ClassNotFoundException
	{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "1234"); 
        String sql = "select * from student";
        PreparedStatement ps = con.prepareStatement(sql);
                
        ResultSet rs = ps.executeQuery();
        
        
       while(rs.next())
       {
    	   Student s = new Student();
    	   s.setSid(rs.getInt(1));
    	   s.setName(rs.getString(2));
    	   s.setEmail(rs.getString(3));
    	   s.setCourse(rs.getString(4));
    	   
    	   al.add(s);    	   
       }
       return al;
  	}
	
	
    
	public void deleteStudent(Student student) throws SQLException, ClassNotFoundException
	{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "1234"); 
        

        String sql = "DELETE FROM student WHERE sid = ?";

        PreparedStatement ps = con.prepareStatement(sql);

        ps.setInt(1, student.getSid());
        
        ps.executeUpdate();

		
		
	}
	 
	public void UpdateStudent(Student student) throws SQLException, ClassNotFoundException {
	    Class.forName("com.mysql.cj.jdbc.Driver");
	    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "1234"); 

	    String sql = "UPDATE student SET name=?, email=?, course=? WHERE sid=?";
	    PreparedStatement ps = con.prepareStatement(sql);
	    ps.setString(1, student.getName());
	    ps.setString(2, student.getEmail());
	    ps.setString(3, student.getCourse());
	    ps.setInt(4, student.getSid());

	    ps.executeUpdate();
	}

	
	
}
